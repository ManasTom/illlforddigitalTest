var firebaseConfig = {
    apiKey: "AIzaSyAw1iaOwMTxgmlz4MV7CYa59Ma89y2fg8E",
    authDomain: "illfordadmin.firebaseapp.com",
    databaseURL: "https://illfordadmin-default-rtdb.firebaseio.com",
    projectId: "illfordadmin",
    storageBucket: "illfordadmin.appspot.com",
    messagingSenderId: "569304509474",
    appId: "1:569304509474:web:6e934d68c9a731389bee7b"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);