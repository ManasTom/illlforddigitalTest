const firstDiva = document.querySelector('.services_page_section4_colItem1');
const secondDiva = document.querySelector('.services_page_section4_colItem2');
const thirdDiva = document.querySelector('.services_page_section4_colItem3');
secondDiva.style.height = `${firstDiva.clientHeight}px`;
thirdDiva.style.height = `${firstDiva.clientHeight}px`;

const fourthDiva = document.querySelector('.services_page_section4_colItem4');
const fifthDiva = document.querySelector('.services_page_section4_colItem5');
const sixthDiva = document.querySelector('.services_page_section4_colItem6');
fourthDiva.style.height = `${sixthDiva.clientHeight}px`;
fifthDiva.style.height = `${sixthDiva.clientHeight}px`;


const firstDivb = document.querySelector('.services_page_section5_colItem1');
const secondDivb = document.querySelector('.services_page_section5_colItem2');
const thirdDivb = document.querySelector('.services_page_section5_colItem3');
secondDivb.style.height = `${firstDivb.clientHeight}px`;
thirdDivb.style.height = `${firstDivb.clientHeight}px`;

const fourthDivb = document.querySelector('.services_page_section5_colItem4');
const fifthDivb = document.querySelector('.services_page_section5_colItem5');
const sixthDivb = document.querySelector('.services_page_section5_colItem6');
fourthDivb.style.height = `${sixthDivb.clientHeight}px`;
fifthDivb.style.height = `${sixthDivb.clientHeight}px`;
