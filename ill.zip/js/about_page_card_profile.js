const firstDiv = document.querySelector('.about_page_meetourteam_team_1_card');
const secondDiv = document.querySelector('.about_page_meetourteam_team_2_card');
const thirdDiv = document.querySelector('.about_page_meetourteam_team_3_card');
const fourthDiv = document.querySelector('.about_page_meetourteam_team_4_card');
secondDiv.style.height = `${firstDiv.clientHeight}px`;
thirdDiv.style.height = `${firstDiv.clientHeight}px`;
fourthDiv.style.height = `${firstDiv.clientHeight}px`;





const card1 = document.querySelector('.about_page_meetourteam_team_11_card');
const card2 = document.querySelector('.about_page_meetourteam_team_22_card');
const card3 = document.querySelector('.about_page_meetourteam_team_33_card');
const card4 = document.querySelector('.about_page_meetourteam_team_44_card');
card2.style.height = `${card1.clientHeight}px`;
card3.style.height = `${card1.clientHeight}px`;
card4.style.height = `${card1.clientHeight}px`;